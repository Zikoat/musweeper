
def play_env(model, env):
    pass